![Ostranauts](https://img.shields.io/badge/Game-Ostranauts-blue?style=for-the-badge) ![BepInEx 5](https://img.shields.io/badge/Framework-BepInEx%205-green?style=for-the-badge) ![Unity 5.6](https://img.shields.io/badge/Unity-5.6-lightgrey?style=for-the-badge) ![Version](https://img.shields.io/badge/Version-1.0-orange?style=for-the-badge)

# 🇷🇺 RUS_CoreForgeLabs v1.0

**Полная русификация + оптимизация производительности для Ostranauts**  
**Complete Russian translation + performance optimization for Ostranauts**

[❤️ Поддержка](#-support--поддержка) • [📦 Установка](#-installation--установка) • [🔧 Что входит](#-whats-included--что-входит) • [⚙️ Настройка](#️-configuration--настройка)

---

## ❤️ Support / Поддержка

**Made with love by [@CoreForgeLabs](https://t.me/CoreForgeLabs)**  
Telegram · Discord

Это одна из моих любимых игр, и я искренне хочу развивать наше небольшое сообщество.
Ваша поддержка — это не просто финансовая помощь. Это мотивация продолжать
и уверенность, что проект кому-то действительно важен.

This is one of my favorite games, and I truly want to grow our small community.
Your support motivates me to keep developing and improving the mod.

| | |
|--------|---------|
| **Boosty** | [boosty.to/coreforgelabs](https://boosty.to/coreforgelabs) |
| **Tbank** | `2200 7013 8955 0366` |
| **BTC** | `bc1qjzw4nz6y0dl3pvy8v46j70yywsh4l78sg0eq3x` |
| **ETH / USDT / USDC (ERC-20)** | `0xc9B7c16ef301E6277BbEB28C9AfCEC7c107d244E` |

**Помимо модов / Besides modding:**
🤖 Telegram/Discord боты • ⚙️ Автоматизация • 🔗 Интеграции • 🌍 Переводы игр

**Пишите — отвечу всем! / Feel free to reach out! :)**

---

## 🔧 What's included / Что входит

### 🇷🇺 Русский перевод

| Компонент | Описание |
|-----------|----------|
| **RUS_CoreForgeLabs** | Перевод всех игровых данных: взаимодействия, условия, предметы, карьеры, сюжет, подсказки (107 JSON-файлов) |
| **OstranautsRusPatch v4.0** | BepInEx-плагин: удаление артиклей, замена местоимений (he/she → он/она), перевод характеристик, профессий, активных смен |
| **XUnity AutoTranslator** | Перевод элементов интерфейса Unity |
| **Русские имена** | Имена, фамилии и названия кораблей на русском |
| **Текстуры** | Русские текстуры кнопок главного меню |

### ⚡ Оптимизация производительности

| Плагин | Что делает |
|--------|-----------|
| **SaveForce** | Загрузка сейвов **в 2 раза быстрее** (72с → 33с). 16 патчей: параллельный парсинг, кеширование, пропуск визуалов |
| **OstronautsOptimizer** | Устраняет **фризы 0.5–1.5с** во время игры. Расширение кучи, троттлинг симуляции, снижение аллокаций |
| **Run** | Авто-загрузка последнего сейва при запуске через RUNSAVE.bat |

---

## 📦 Installation / Установка

1. Скопируйте **всё содержимое этой папки** в папку игры:
   ```
   C:\...\steamapps\common\Ostranauts\
   ```
   (туда, где лежит `Ostranauts.exe`)

2. На вопрос «Заменить файлы?» → **Да для всех**

3. Запустите игру через Steam. **Готово!**

В папке с игрой должно быть:
```
Ostranauts\
├── winhttp.dll                  ← новое
├── doorstop_config.ini          ← новое
├── RUNSAVE.bat                  ← новое (быстрая загрузка)
├── BepInEx\
│   ├── core\*.dll               ← фреймворк
│   ├── config\
│   │   ├── AutoTranslatorConfig ← настройки перевода UI
│   │   └── optimizer.cfg        ← настройки оптимизатора
│   ├── plugins\
│   │   ├── OstranautsRusPatch   ← плагин перевода
│   │   ├── OstronautsOptimizer  ← оптимизатор
│   │   ├── SaveForce            ← ускорение загрузки
│   │   ├── Run                  ← авто-загрузка
│   │   ├── rus_*.json           ← словари перевода
│   │   └── XUnity.*             ← перевод UI
│   └── Translation\ru\          ← файлы перевода UI
├── Ostranauts.exe
└── Ostranauts_Data\
    ├── Mods\
    │   ├── loading_order.json   ← порядок загрузки модов
    │   └── RUS_CoreForgeLabs\   ← 107 файлов данных перевода
    └── StreamingAssets\
        ├── data\names_*\        ← русские имена
        └── images\              ← русские текстуры
```

---

## 🚀 Quick-Load / Быстрая загрузка

Создайте ярлык на `RUNSAVE.bat` на рабочем столе.
Двойной клик — мгновенный запуск игры с загрузкой последнего сейва, **без меню!**

---

## ❌ Uninstallation / Удаление

**Удаление перевода :**
- `BepInEx\plugins\OstranautsRusPatch.dll`
- `BepInEx\plugins\rus_*.json`
- `Ostranauts_Data\Mods\RUS_CoreForgeLabs\`
- `BepInEx\Translation\ru\`
- `BepInEx\config\AutoTranslatorConfig.ini`

**Удаление оптимизатора:**
- `BepInEx\plugins\OstronautsOptimizer.dll`
- `BepInEx\plugins\SaveForce.dll`
- `BepInEx\plugins\Run.dll`

**Полное удаление BepInEx:** удалите `winhttp.dll`, `doorstop_config.ini` и папку `BepInEx\`

---

## ⚙️ Configuration / Настройка

После первого запуска в `BepInEx\config\` появятся конфиг-файлы:

### SaveForce (`com.coreforgelabs.saveforce.cfg`)

| Параметр | По умолч. | Описание |
|----------|-----------|----------|
| `ParallelShips` | true | Параллельный парсинг JSON кораблей |
| `ReduceYields` | true | Пакетная обработка yield-операций |
| `YieldBatchSize` | 50 | Объектов за один батч |
| `ConditionCache` | true | Кеширование парсинга условий |
| `KillDuplicates` | true | Автозакрытие дублей игры |

### OstronautsOptimizer (`com.perf.ostranauts.optimizer.cfg`)

| Параметр | По умолч. | Описание |
|----------|-----------|----------|
| `HeapExpansionMB` | 1024 | Расширение кучи (0=выкл, 512=хорошо, **1024=рекомендуется**) |
| `FrameBudgetMs` | 12 | Бюджет фрейма для симуляции (мс) |
| `MaxSimStepsPerFrame` | 50 | Макс шагов симуляции за фрейм |
| `MaxDeltaTime` | 0.1 | Ограничение deltaTime после GC |

### Run (`com.coreforgelabs.run.cfg`)

| Параметр | По умолч. | Описание |
|----------|-----------|----------|
| `AutoLoadMostRecentSave` | false | Авто-загрузка при каждом запуске (true) или только через RUNSAVE.bat (false) |

---

## 🛠️ How it works / Как работает

### SaveForce — ускорение загрузки

16 Harmony-патчей, сокращающих загрузку с ~72–82с до ~33с (56–60% быстрее):

- **Параллельный парсинг JSON** — данные кораблей парсятся в фоновых потоках
- **Кеширование условий** — 460K+ условий в кеше
- **ParseCondEquation cache** 
- **CondRule cache**
- **Пропуск UpdateFaces при загрузке** — 507K вызовов пропущено
- **Пропуск VisualizeOverlays при загрузке** — 78K вызовов пропущено
- **Пакетные yield-операции** — снижение оверхеда корутин Unity
- **Inter-batch GC** — сборка мусора между батчами загрузки

### OstronautsOptimizer — рантайм-оптимизация

- **Heap Pre-Expansion** — расширяет Mono heap после загрузки, GC запускается раз в ~100с вместо каждых ~5с
- **Sim Loop Throttling** — не даёт симуляции съесть весь бюджет фрейма
- **Allocation Reduction** — LINQ → прямой доступ, кеширование запросов

### OstranautsRusPatch — плагин перевода

- Удаление английских артиклей (the, a, an, your, his, her)
- Замена местоимений (he/she/they → он/она/они)
- Исправление грамматики (спряжение, падежи)
- Перевод 140+ характеристик персонажей
- Перевод профессий и активных смен
- Таблица перевода повреждений (DAMAGE → ПОВРЕЖДЕНИЯ)
- И многое другое

---

## 📋 Совместимость

- Тестировалось на Ostranauts v0.14.5.20, но должен работать и после обновлений

---

© 2026 CoreForgeLabs
